public interface ILogger {
    public void write(String message);
}
