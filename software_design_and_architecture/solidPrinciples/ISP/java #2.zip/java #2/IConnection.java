public interface IConnection {
    public  void openConnection();
    public  void closeConnection();    
}
