public interface IKlima {
    void open();
}
