public interface ITurbo {
    void boost();
}
